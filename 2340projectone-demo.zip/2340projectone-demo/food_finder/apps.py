from django.apps import AppConfig


class FoodFinderConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "food_finder"
